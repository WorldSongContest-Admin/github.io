WSC GenZ 48 qualifier reveal files

Copy scripts/qualifier_reveal.py and reveal_entries.json to your repository.
Replace .github/workflows/discord-reveal.yml with the included workflow.

Before Preview/Live, fill reveal_entries.json with all 43 semifinal entries.
Each entry: {"country":"Country name","semifinal":1,"qualified":true,"youtube_id":"VIDEO_ID"}
Semifinal 1 must have 21 entries and exactly 12 true qualifiers.
Semifinal 2 must have 22 entries and exactly 12 true qualifiers.

The Test mode is safe and works before results are entered.
Preview requires confirmed data, but does not post anything.
Live requires confirmation REVEAL48. Do not run Live twice.

IMPORTANT: This is a starting implementation. GitHub Actions runners are ephemeral:
reveal_state.json is not persisted automatically between workflow runs.
Before using Live, add durable GitHub-side run locking/state or manual protection
so a second run cannot duplicate the reveal. A failed request may have posted.
Do not use Live until that safeguard is implemented and verified.
